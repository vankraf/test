self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e357a606ba8e3ca89eaac0663644afb3",
    "url": "/test/index.html"
  },
  {
    "revision": "fd2532c7c7883ff0a9fe",
    "url": "/test/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "e51ba33b7194f4c480f7",
    "url": "/test/static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "fd2532c7c7883ff0a9fe",
    "url": "/test/static/js/2.2041bbaa.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/test/static/js/2.2041bbaa.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e51ba33b7194f4c480f7",
    "url": "/test/static/js/main.7e0ba8ac.chunk.js"
  },
  {
    "revision": "a2a118daa8ca02cff825",
    "url": "/test/static/js/runtime-main.5ebfacb6.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/test/static/media/persik.4e1ec840.png"
  }
]);